import time
from pathlib import Path
import os
#import pandas as pd
import datetime
import cv2
#import cv2.xfeatures2d
import torch
import torch.backends.cudnn as cudnn
from numpy import random
#from flask import Flask, render_template, Response
import csv
import numpy as np
import pandas as pd
import json

from models.experimental import attempt_load
from utils.datasets import LoadStreams, LoadImages
from utils.general import check_img_size, non_max_suppression, apply_classifier, scale_coords, xyxy2xywh, \
    strip_optimizer, set_logging, increment_path
from utils.plots import plot_one_box
from utils.torch_utils import select_device, load_classifier, time_synchronized
class_names = ['Plane', 'Ground Power Source', 'Power Hose', 'Luggage Truck', 
               'Plane door', 'Aero Bridge', 'People', 'Aircraft Ramp']

def detect(filename, save_path_v,save_path_img,save_path_js, Img_Path):
    save_img = True
    weights = "Model/weights/best.pt"
    base_source = "Test/"
    # save_path_txt='/Users/lalehasadzadeh/anaconda3/lib/python3.10/site-packages/RealTime_Detection-And-Classification-of-TrafficSigns/'
    # save_path_img=save_path_txt+str(os.path.splitext(filename)[0])
    print('filename_type',type(filename))
    source=base_source+str(filename)
    print('source', source)
    n_frames = 40
    imgsz = 416
    conf_thres = 0.8
    iou_thres=0.45
    device = ''
    view_img=True
    save_txt = False
    classes = None
    agnostic_nms = False
    webcam = source.isnumeric() or source.endswith('.txt') or source.lower().startswith(
        ('rtsp://', 'rtmp://', 'http://'))

    # Directories
    save_dir = Path(increment_path(Path('Results'), exist_ok='ok'))  # increment run
    (save_dir / 'labels' if save_txt else save_dir).mkdir(parents=True, exist_ok=True)  # make dir

    # Initialize
    set_logging()
    device = select_device(device)
    half = device.type != 'cpu'  # half precision only supported on CUDA

    # Load model
    model = attempt_load(weights, map_location=device)  # load FP32 model
    imgsz = check_img_size(imgsz, s=model.stride.max())  # check img_size
    if half:
        model.half()  # to FP16

    # Set Dataloader
    vid_path, vid_writer = None, None
    if webcam:
        view_img = True
        cudnn.benchmark = True  # set True to speed up constant image size inference
        dataset = LoadStreams(source, img_size=imgsz)
    else:
        view_img = True
        save_img = True
        dataset = LoadImages(source, img_size=imgsz)
    print('dataset',dataset)

    # Get names and colors for the bounding boxes.
    names = model.module.names if hasattr(model, 'module') else model.names
    colors = [[random.randint(0, 255) for _ in range(3)] for _ in names]

    # Run inference
    t0 = time.time()
    img = torch.zeros((1, 3, imgsz, imgsz), device=device)  # init img
    _ = model(img.half() if half else img) if device.type != 'cpu' else None  # run once

    # Initialize previous detections
    object_status = []
    file_path_UniqObj=save_path_js
    with open(file_path_UniqObj, mode='w') as f:
        json.dump(object_status, f)

    # file_path = 'Results/object_status.json'
    # with open(file_path, mode='w') as f:
    #     json.dump(object_status, f)

    frame=0
    for path, img, im0s, vid_cap in dataset:
        img = torch.from_numpy(img).to(device)
        img = img.half() if half else img.float()  # uint8 to fp16/32
        img /= 255.0  # 0 - 255 to 0.0 - 1.0
        frame=frame+1
        frame_name=str(frame)+'.jpeg'
        print('frame_name',frame_name)
        
        save_images_path=f"{save_path_img}/{frame_name}"
        save_images_path2=f"{Img_Path}/{frame_name}"
        print('save_images_path',save_images_path)
        if frame >n_frames:
            break
        if img.ndimension() == 3:
            img = img.unsqueeze(0) 

        # Inference        
        t1 = time_synchronized()        #Time T1

        pred = model(img, augment=False)[0]
        #print(pred)

         # Apply NMS
        pred = non_max_suppression(pred, conf_thres, iou_thres, classes=classes, agnostic=agnostic_nms)   
        print("pred in first format\n",pred)
        pred_np=pred[0].detach().numpy()
        #print("pred in numpy format \n",pred_np)
        pred_df=pd.DataFrame(pred_np)
        pred_df.columns=['x_center', 'y_center', 'width', 'height', 'proba', 'item_id']
        pred_df['class']=pred_df['item_id'].apply(lambda x: class_names[int(x)])
        now=datetime.datetime.now()
        foematted_time=now.strftime("%d-%m-%Y %H:%M:%S:%f")[:-3]
        pred_df['time']=foematted_time
        pred_df=pred_df[['item_id','class','time','x_center', 'y_center', 'width', 'height']]
        #print("pred in pandas format\n",pred_df)
        pred_dict={'frame':frame,'path': str(save_images_path2) ,'objects':pred_df.to_dict(orient='records')}
        #print("pred in dict format\n",pred_dict)
        with open(file_path_UniqObj, "r") as file:
            data = json.load(file)
        with open(file_path_UniqObj, "w") as file:
            data.append(pred_dict)
            file.seek(0)
            json.dump(data, file)

        t2 = time_synchronized()        #Time T2
            
        # Initialize previous detections

        object_status={'frame': frame}
        #print("the object status start of main main for loop",object_status)
        # Process detections
        for i, det in enumerate(pred):  # detections per image
                        
            if webcam:  # batch_size >= 1
                p, s, im0 = Path(path[i]), '%g: ' % i, im0s[i].copy()
            else:
                p, s, im0 = Path(path), '', im0s
            print('Path(path)', Path(path))

            save_path = str(save_dir / p.name)
            print('save_path', save_path)
            txt_path = str(save_dir / 'labels' / p.stem) + ('_%g' % dataset.frame if dataset.mode == 'video' else '')
            print('txt_path', txt_path)
            s += '%gx%g ' % img.shape[2:]  # print string
            print('print string', s)
            gn = torch.tensor(im0.shape)[[1, 0, 1, 0]]  # normalization gain whwh
            if len(det):
                # Rescale boxes from img_size to im0 size
                det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape).round()

                # Print results
                for c in det[:, -1].unique():
                    n = (det[:, -1] == c).sum()  # detections per class
                    s += '%g %ss, ' % (n, names[int(c)])  # add to string

                # Plot the bounding boxes.
                for *xyxy, conf, cls in reversed(det):
                    if save_img or view_img:
                        label = '%s %.2f' % (names[int(cls)], conf)
                        #print(label)
                        plot_one_box(xyxy, im0, label=label, color=colors[int(cls)], line_thickness=3)

            # Print time (inference + NMS)
            #print('%sDone. (%.3fs)' % (s, t2 - t1))
            try:
                im0 = cv2.putText(im0, "FPS: %.2f" %(1/(t2-t1)), (30,30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,0,255), 2, cv2.LINE_AA)
            except:
                pass
            
            # saving the image or video to the Results directory.
            save_img=True
            if save_img:
                if dataset.mode == 'images':
                    cv2.imwrite(save_images_path, im0)
                else:
                    cv2.imwrite(save_images_path, im0)
                    # if vid_path != save_path:  # new video
                    #     vid_path = save_path
                    #     if isinstance(vid_writer, cv2.VideoWriter):
                    #         vid_writer.release()  # release previous video writer

                    #     fourcc = 'mp4v'  # output video codec
                    #     fps = vid_cap.get(cv2.CAP_PROP_FPS)
                    #     print('dataset.mode: ', dataset.mode)
                    #     print(f'FPS of video {fps}')
                    #     w = int(vid_cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                    #     h = int(vid_cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                    #     vid_writer = cv2.VideoWriter(save_path_v, #save_path, 
                    #                                  cv2.VideoWriter_fourcc(*fourcc), fps, (w, h))
                    # vid_writer.write(im0)

            # # Stream live results
            # if view_img:
            #     cv2.imshow("Images", im0)

            #     print("\n\n**********************************")
            #     print("type",type(cv2.imshow("Images", im0)))
            #     if dataset.is_it_web:
            #         if cv2.waitKey(1) & 0xFF == ord('q'):  # q to quit
            #             raise StopIteration
            #     else:
            #         if dataset.video_flag[0]:
            #             if cv2.waitKey(1) & 0xFF == ord('q'):  # q to quit
            #                 raise StopIteration
            #         else:
            #             if cv2.waitKey(0) & 0xFF == ord('q'):  # q to quit
            #                 raise StopIteration     


if __name__ == '__main__':
    with torch.no_grad():
            detect()
