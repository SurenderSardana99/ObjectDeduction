import os
import json
import asyncio
from fastapi import FastAPI, Response, Body
from fastapi.middleware.cors import CORSMiddleware

from predict_Img_Local import detect


origins = [
    "http://localhost",
    "http://localhost:8080",
    "http://localhost:5173",
    "http://localhost:5174",
    "http://localhost:5175"  # Add the React application's origin here
]

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["Content-Disposition"]  # Add any additional headers you need to expose
)


# origins = ["http://localhost",
#            "http://localhost:8080", 
#            "http://localhost:5173"]

# app = FastAPI()


# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=origins,
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"]
# )


async def async_create_result_paths(video_name: str):
    # Create Outputs directory if it doesn't exist
    
    output_dir = 'Outputs/'  
    filename_v = f"{video_name}"
    filename_j = f"{video_name}.json" 
    Img_Path=f"/Outputs/{video_name}/"


    # Specify the filename with full path
    save_path_json = output_dir+f"/{filename_j}"
    save_path_Images = output_dir+f"/{filename_v}"
    os.makedirs(save_path_Images, exist_ok=True)

    data = {}
    with open(save_path_json, 'w+') as f:
        json.dump(data, f)
    detect(filename=f"{video_name}.mp4", 
           save_path_v=filename_v, 
           save_path_img=save_path_Images, 
           save_path_js=save_path_json, 
           Img_Path=Img_Path)

@app.get("/run_detection")
async def trigger_detection(video_name: str):
    filename_v = f"{video_name}"
    filename_j = f"{video_name}.json"
    output_dir = 'Outputs/'
    save_path_json = output_dir+f"{filename_j}"
    save_path_Images = output_dir+f"{filename_v}"
    os.makedirs(save_path_Images, exist_ok=True)

    # Start the create_result_paths function in the background
    asyncio.create_task(async_create_result_paths(video_name))

    return {
        "save_path_Images": save_path_Images,
        "save_path_json": save_path_json
        }


if __name__ == "__main__":
    import uvicorn
    import os

    # Read the port number from an environment variable
    port = int(os.environ.get("MY_APP_PORT", 8000))
    
    uvicorn.run(app, host="0.0.0.0", port=port)


# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="0.0.0.0", port=4000)

# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app)
